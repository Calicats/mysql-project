import java.io.File;
import java.io.FileNotFoundException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        try {
            Scanner contents = new Scanner(new File("user.txt"));
            String user = contents.next();
            String password = contents.next();
            System.out.println(user + " " + password);
        } catch (FileNotFoundException e) {
            System.err.println("user.txt: no such file or directory");
        } catch (NoSuchElementException e) {
            System.err.println("user.txt: incorrect formatting");
            System.err.println("should be username and password separated by whitespace");
        } catch (Exception e) {
            e.printStackTrace(System.err);
        }
    }
}